# Pulls changes from forks
# Run before any works
git pull upstream master
git remote add github https://github.com/anujdutt9/Handwritten-Digit-Recognition-using-Deep-Learning.git
git pull github master
git remote add github-fork https://github.com/Baneeishaque/Handwritten-Digit-Recognition-using-Deep-Learning.git
git pull github-fork master
